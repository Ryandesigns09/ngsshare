import axios from 'axios'
import express, { Request, Response } from 'express'
import puppeteer from 'puppeteer'
import cors from 'cors'

const port = process.env.PORT || 3000
const appEnv = process.env.APP_ENV || 'dev'
const backendUrl = appEnv === 'prod' ? 'https://mysterious-earth-89045.herokuapp.com' : `http://localhost:${port}`
const app = express()
app.use(cors())

const renderImage = async (graphicId: string) => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] })
  const page = await browser.newPage()
  page.setViewport({
    width: 1920,
    height: 1080,
    deviceScaleFactor: 1,
  })
  await page.goto(`${backendUrl}/graphics/${graphicId}`)
  await page.waitForTimeout(5000)
  const screenshot = await page.screenshot()
  await browser.close()
  return screenshot
}

const renderHtml = (req: Request, res: Response) => {
  res.sendFile('/frontend/dist/index.html', { root: '../' })
}

app.get('/', renderHtml)
app.get('/graphics/:graphicId', renderHtml)
app.get('/share/:graphicId', (req: Request, res: Response) => {
  const graphicId = req.params.graphicId
  res.send(`
  <html>
    <head>
    <title>Title</title>
      <meta property="og:url"         content="${backendUrl}/share/${graphicId}" />
      <meta property="og:type"        content="website" />
      <meta property="og:title"       content="Test Title" />
      <meta property="og:description" content="Test Description" />
      <meta property="og:image"       content="${backendUrl}/render/${graphicId}" />
    </head>
    <body>

    </body>
  </html>
  `)
})

app.use('/public', express.static('../frontend/dist'))

app.get('/render/:graphicId', async (req: Request, res: Response) => {
  const graphicId = req.params.graphicId
  const image = await renderImage(graphicId)
  res.send(image)
})

app.get('/api/leagues/:leagueId/matchups', async (req: Request, res: Response) => {
  const leagueId = req.params.leagueId
  const response = await axios(`https://nhlgamer.com/api/leagues/${leagueId}/matchups`, {
    headers: {
      Authorization:
        'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiODFiZjZjYzc2OTA3N2Y0YWM3NDg0ZTQzMTUwMjY4MDMxMWQzODRhYmQ3YWFhNDhhMjYxOGVjZDZjNzgxNThlNGNlN2IzZDFjNDQyMWJlNGQiLCJpYXQiOjE2MTM0NzQ0NzAsIm5iZiI6MTYxMzQ3NDQ3MCwiZXhwIjoxOTI5MDA3MjI0LCJzdWIiOiIxNDA2MCIsInNjb3BlcyI6WyJsZWFndWU6ODAiXX0.jt4HVFw-GnLxTepdMAfB7j2tWaYj1rLTUzT3jnyUku7sRHyGFJy2LPcickAZKcawtahrXG8B-H9BRkEIaiINUahUdEOVgvl_0bHA23zKDJjhVKhF_qExCvYZrgkHWMnkqd3rA6frAMBresSmm2RAFloxBo8QpxBhCfyyiNWuaBhY66z8_wMVIVSydA2hVZHOod3qF8s6hS4YeEK-zui2SnqP-s_N5o9AN9NB0BMSEUOiJWc0RRp-WEuTEu9Lu3m2ioEiOCu0lclx5qJgv-mlER78CXjpZZpS3ixKnuzGvPLVlZ_xcJrTkDCxzUamRGtlVndATk5N3OKI3jXadxxTN5A0O9Fz3T1s4EYd06T8V7SiGAJ3ph9qyfPIhC95RJrC2dIfxa9akGFNie80MThSZbZqqc39GwVibq14bLYQ4YLO9rUnHYYCXN47hbezig6xmtYd14REurKa_heHI57rbZl5zICPYlxW2QvLe2PYbeEFWcaiH8B34I89_ODQSPTgAjz-rnMWdiZZh7fG_b0Rom4mWGlhqiibXofyETnIcS3AWhnfUR42uWGxlrqlCaNkdnbRnUSEgfswS_pvvPYnRsy27Br_7WqfzrF1MyGXtV4RoorIyz3XKG4Vd1qJM1zzQGXZ4KGsDeKoBcIGkz4rwaBabiW2KVxRcOKUW8lKDwM',
    },
  })
  res.json(response.data)
})

app.listen(port, () => {
  console.log(`Example app listening at ${backendUrl}`)
})
