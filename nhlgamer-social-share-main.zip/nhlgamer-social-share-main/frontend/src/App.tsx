import React from 'react'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import { Graphic } from './Graphic'
import { Home } from './Home'
import { MatchResult } from './MatchResult'
import { StatisticsProvider } from './StatisticsContext'

export const App = () => {
  return (
    <StatisticsProvider>
      <Router>
        <Switch>
          <Route path="/graphics">
            <Graphic>
              <Route path="/graphics/match-result/:matchId">
                <MatchResult />
              </Route>
            </Graphic>
          </Route>
          <Route path="/">
            <Home />
          </Route>
        </Switch>
      </Router>
    </StatisticsProvider>
  )
}
