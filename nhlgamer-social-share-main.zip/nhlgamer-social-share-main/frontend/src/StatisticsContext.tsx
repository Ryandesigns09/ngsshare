import React, { useEffect, useState } from 'react'
import { getMatches, Match } from './nhlgamer'

type Props = {
  children: React.ReactElement
}

type ContextProps = {
  matches: Match[]
  match: Match | null
  setMatch: (match: Match) => void
}

export const StatisticsContext = React.createContext<ContextProps>({
  matches: [],
  match: null,
  setMatch: (match: Match) => {},
})

export const StatisticsProvider: React.FC<Props> = ({ children }) => {
  const [matches, setMatches] = useState<Match[]>([])
  const [match, setMatch] = useState<Match | null>(null)
  useEffect(async () => {
    const newMatches = await getMatches(94)
    if (newMatches.length) {
      setMatch(newMatches[0])
    }
    setMatches(newMatches)
  }, [])
  return <StatisticsContext.Provider value={{ matches, match, setMatch }}>{children}</StatisticsContext.Provider>
}
