import { Button, CircularProgress, MenuItem, Select } from '@material-ui/core'
import { format } from 'date-fns'
import React, { useContext } from 'react'
import styled from 'styled-components'
import { Graphic } from './Graphic'
import { MatchResult } from './MatchResult'
import { StatisticsContext } from './StatisticsContext'

const Container = styled.div`
  max-width: 1980px;
`

const ControlPanel = styled.div`
  padding: 50px;
  display: grid;
  grid-template-columns: 1fr 1fr;
`

const Buttons = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
`

export const Home = () => {
  const { matches, match, setMatch } = useContext(StatisticsContext)
  const changeMatch = (
    event: React.ChangeEvent<{
      name?: string | undefined
      value: unknown
    }>,
  ) => {
    const match = matches.find(({ id }) => id === event.target.value)
    if (match) {
      setMatch(match)
    }
  }
  if (!matches.length) {
    return <CircularProgress />
  }
  return (
    <Container>
      <ControlPanel>
        {matches.length && (
          <Select value={match?.id || matches[0].id} onChange={changeMatch}>
            {matches.map((match) => (
              <MenuItem key={match.id} value={match.id}>
                {format(new Date(match.date), 'd.M.yyyy')} {match.awayTeam.name} - {match.homeTeam.name}
              </MenuItem>
            ))}
          </Select>
        )}
        <Buttons>
          <a href="/render/match-result">
            <Button variant="contained" color="primary">
              Download
            </Button>
          </a>
          <div
            class="fb-share-button"
            data-href="https://mysterious-earth-89045.herokuapp.com/render/match-result"
            data-layout="button"
            data-size="small"
          >
            <a
              target="_blank"
              href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmysterious-earth-89045.herokuapp.com%2Frender%2Fmatch-result&amp;src=sdkpreparse"
              class="fb-xfbml-parse-ignore"
            >
              Share
            </a>
          </div>
        </Buttons>
      </ControlPanel>
      <Graphic>
        <MatchResult />
      </Graphic>
    </Container>
  )
}
