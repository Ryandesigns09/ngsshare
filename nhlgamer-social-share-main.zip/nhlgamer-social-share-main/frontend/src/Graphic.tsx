import styled from 'styled-components'
import Background from '../assets/background.png'

export const Graphic = styled.div`
  background-image: url('${Background}');
  height: 1080px;
  width: 1920px;
`
