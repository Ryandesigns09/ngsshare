import React, { useContext } from 'react'
import styled from 'styled-components'

import { StatisticsContext } from './StatisticsContext'

const Container = styled.div`
  padding-top: 300px;
  padding-right: 200px;
  padding-left: 200px;
  color: white;
  text-align: center;
`

const Teams = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  justify-content: center;
`

const Team = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  justify-content: center;
`

const Logo = styled.img`
  height: 400px;
  margin-top: 30px;
  margin-bottom: 30px;
`

const Goal = styled.h2`
  font-size: 128px;
`

const Statistic = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr 1fr;
`

const StatisticName = styled.div`
  font-size: 48px;
  font-weight: bold;
`

const StatisticValue = styled.div`
  font-size: 48px;
`

export const MatchResult = () => {
  const { match } = useContext(StatisticsContext)
  if (!match?.result) {
    return null
  }
  return (
    <Container>
      <Teams>
        <Team>
          <Logo src={match.homeTeam.logo} />
          <Goal>{match.result.goalsHome}</Goal>
        </Team>
        <Team>
          <Goal>{match.result.goalsAway}</Goal>
          <Logo src={match.awayTeam.logo} />
        </Team>
      </Teams>
      <Statistic>
        <StatisticValue>{match.result.shotsHome}</StatisticValue>
        <StatisticName>Shots</StatisticName>
        <StatisticValue>{match.result.shotsAway}</StatisticValue>
      </Statistic>
      <Statistic>
        <StatisticValue>{match.result.faceoffWinsHome}</StatisticValue>
        <StatisticName>Faceoff Wins</StatisticName>
        <StatisticValue>{match.result.faceoffWinsAway}</StatisticValue>
      </Statistic>
      <Statistic>
        <StatisticValue>{match.result.hitsHome}</StatisticValue>
        <StatisticName>Hits</StatisticName>
        <StatisticValue>{match.result.hitsAway}</StatisticValue>
      </Statistic>
      <Statistic>
        <StatisticValue>{match.result.penaltiesHome}</StatisticValue>
        <StatisticName>Penalties</StatisticName>
        <StatisticValue>{match.result.penaltiesAway}</StatisticValue>
      </Statistic>
    </Container>
  )
}
