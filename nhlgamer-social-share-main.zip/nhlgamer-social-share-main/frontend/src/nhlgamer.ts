import axios from 'axios'
import * as zod from 'zod'

const teamSchema = zod.object({
  abbreviation: zod.string(),
  group: zod.number(),
  id: zod.number(),
  logo: zod.string(),
  name: zod.string(),
})

const matchResultSchema = zod.object({
  date: zod.string(),
  faceoffWinsAway: zod.number(),
  faceoffWinsHome: zod.number(),
  goalsAway: zod.number(),
  goalsHome: zod.number(),
  hitsAway: zod.number(),
  hitsHome: zod.number(),
  id: zod.number(),
  overtime: zod.boolean(),
  penaltiesAway: zod.number(),
  penaltiesHome: zod.number(),
  reportDate: zod.string(),
  shotsAway: zod.number(),
  shotsHome: zod.number(),
  status: zod.string(),
  timeOnAttackAway: zod.string(),
  timeOnAttackHome: zod.string(),
})

const matchSchema = zod.object({
  id: zod.number(),
  date: zod.string(),
  type: zod.string(),
  homeTeam: teamSchema,
  awayTeam: teamSchema,
  result: matchResultSchema.optional(),
})

export type Match = zod.infer<typeof matchSchema>
export type MatchResult = zod.infer<typeof matchResultSchema>
export type Team = zod.infer<typeof teamSchema>

export const getMatches = async (leagueId: number): Promise<Match[]> => {
  const response = await axios(`/api/leagues/${leagueId}/matchups`)
  const matches: Match[] = response.data.map((match: any) => matchSchema.parse(match))
  return matches
}
